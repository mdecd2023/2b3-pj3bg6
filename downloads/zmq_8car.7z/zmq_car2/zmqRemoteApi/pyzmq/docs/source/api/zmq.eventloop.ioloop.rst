
eventloop.ioloop
================

Module: :mod:`eventloop.ioloop`
-------------------------------

This module is deprecated in pyzmq 17.
Use :py:mod:`tornado.ioloop`.
