# pip install pyzmq cbor keyboard
from zmqRemoteApi import RemoteAPIClient
import keyboard
import random
import math

client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')
#sim.startSimulation()
print('Simulation started')

def setBubbleRobVelocity(leftWheelVelocity1, rightWheelVelocity1,leftWheelVelocity2, rightWheelVelocity2):
    leftMotor1 = sim.getObject('/lM2_1')
    rightMotor1 = sim.getObject('/rM2_1')
    leftMotor2 = sim.getObject('/lM2_2')
    rightMotor2 = sim.getObject('/rM2_2')
    sim.setJointTargetVelocity(leftMotor1, leftWheelVelocity1)
    sim.setJointTargetVelocity(rightMotor1, rightWheelVelocity1)
    sim.setJointTargetVelocity(leftMotor2, leftWheelVelocity2)
    sim.setJointTargetVelocity(rightMotor2, rightWheelVelocity2)
    #輸入四個變數分別給四個軸速度
    
def setBubbleRobangel(a):
    bR= sim.getObject('/bR2')
    angel = [-90*math.pi/180, a*math.pi/180, 0]
    leftMotor = sim.getObject('/lM2_1')
    rightMotor = sim.getObject('/rM2_1')
    sim.setObjectOrientation(leftMotor, bR, angel)
    sim.setObjectOrientation(rightMotor, bR, angel)
    #輸入一個變數改變前輪方向
  
while True:
    if keyboard.is_pressed('w'):
        setBubbleRobVelocity(4, 4, 4, 4)
        if keyboard.is_pressed('a'):
            setBubbleRobangel(-40)
        elif keyboard.is_pressed('d'):
            setBubbleRobangel(40)
        else:
            setBubbleRobangel(0)
    elif keyboard.is_pressed('s'):
        setBubbleRobVelocity(-4, -4, -4, -4)
        if keyboard.is_pressed('a'):
            setBubbleRobangel(-40)
        elif keyboard.is_pressed('d'):
            setBubbleRobangel(40)
        else:
            setBubbleRobangel(0)
    elif keyboard.is_pressed('a'):
        setBubbleRobVelocity(-4, 4, -4, 4)
    elif keyboard.is_pressed('d'):
        setBubbleRobVelocity(4, -4, 4, -4)
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
    else:
        setBubbleRobVelocity(0, 0, 0, 0)
        setBubbleRobangel(0)




