# Notes from developing PyZMQ

These are old notes from the early days of developing pyzmq,
back when we needed to support Python 2.5 and 3.1.

```{toctree}
---
maxdepth: 1
---
pyversions.rst
unicode.rst
```
